//
//  CheetahMobileAdsDefines.h
//  CheetahMobileAds
//
//  Created by 李 柯良 on 16/4/12.
//  Copyright © 2016年 cheetahmobile. All rights reserved.
//

#if defined(__cplusplus)
#define CMA_EXTERN extern "C" __attribute__((visibility("default")))
#else
#define CMA_EXTERN extern __attribute__((visibility("default")))
#endif
