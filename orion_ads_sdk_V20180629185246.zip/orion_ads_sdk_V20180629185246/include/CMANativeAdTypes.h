//
//  CMANativeAdTypes.h
//  CheetahMobileAds
//
//  Created by 李 柯良 on 16/4/26.
//  Copyright © 2016年 cheetahmobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CheetahMobileAdsDefines.h>

CMA_EXTERN NSString * const kCMANativeAdLoaderNewsFeed;
CMA_EXTERN NSString * const kCMANativeAdLoaderMiniFeed;
CMA_EXTERN NSString * const kCMANativeAdLoaderTripleImages;
CMA_EXTERN NSString * const kCMANativeAdLoaderSmallImage;