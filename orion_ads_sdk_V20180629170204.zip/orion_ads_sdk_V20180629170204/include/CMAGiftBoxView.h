//
//  CMAGiftBoxView.h
//  CheetahMobileAds
//
//  Created by 李 柯良 on 16/6/24.
//  Copyright © 2016年 cheetahmobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMAPosIDConfig.h"
#import "CMAGiftBoxViewDelegate.h"

@interface CMAGiftBoxView : UIImageView

+ (instancetype)sharedInstance;
- (void)loadAd;

@property (nonatomic, readonly, assign) BOOL isReady;
@property (nonatomic, readonly) NSString *adTitle;

@property (nonatomic, copy) CMAPosIDConfig *posIDConfig;
@property (nonatomic, weak) IBOutlet UIViewController *rootViewController;
@property (nonatomic, weak) IBOutlet id<CMAGiftBoxViewDelegate> delegate;

@end
